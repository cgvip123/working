package FormBeanDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import FormBean.Formsfactory;
import LoginPageBean.LoginPageFactory;

public class webDriver 
{
	public static void main(String[] args) throws Throwable
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:/Users/VIPUTHAK/Desktop/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/VIPUTHAK/Desktop/WorkingWithForms.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Formsfactory obj = new Formsfactory(driver);
		
		obj.setUserName("Vipul");Thread.sleep(500);
		obj.setPassword("78415445641");Thread.sleep(500);
		obj.setConfPassword("78415445641");Thread.sleep(500);
		obj.setFirstName("Vipul");Thread.sleep(500);
		obj.setLastName("Thakur");Thread.sleep(500);
		obj.setGender_male();Thread.sleep(500);
		obj.setDob("20/2/2018");Thread.sleep(500);
		obj.setEmail("vipul.thakur@gmail.com");Thread.sleep(500);
		obj.setCity("Pune");Thread.sleep(500);
		obj.setPhone("78518518784");Thread.sleep(500);
		obj.setHobbies("Music");
		obj.setHobbies("Reading");Thread.sleep(500);
		obj.setRstButton();
		
	}

}
