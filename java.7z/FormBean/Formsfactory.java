package FormBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Formsfactory 
{
	WebDriver driver;
	public Formsfactory(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id="txtUserName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement password;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement confPassword;
	
	@FindBy(css="input.Format1")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(name="txtLN")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="rbMale")
	@CacheLookup
	WebElement gender_male;
	
	@FindBy(id="rbFemale")
	@CacheLookup
	WebElement gender_female;
	
	@FindBy(id="DOB")
	@CacheLookup
	WebElement dob;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="City")
	@CacheLookup
	WebElement city;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phone;

	@FindBy(name="chkHobbies")
	@CacheLookup
	WebElement hobbies;
	
	@FindBy(name="reset")
	@CacheLookup
	WebElement rstButton;
	
	

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getConfPassword() {
		return confPassword;
	}

	public void setConfPassword(String confPassword) {
		this.confPassword.sendKeys(confPassword);
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	
	public WebElement getGender_male() {
		return gender_male;
	}

	public void setGender_male() {
		this.gender_male.click();
	}

	public WebElement getGender_female() {
		return gender_female;
	}

	public void setGender_female() {
		this.gender_female.click();
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob.sendKeys(dob);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
//		Select drpcity = this.city;
		Select drpcity = new Select(this.city);
		drpcity.selectByVisibleText(city);
//		this.city.selectByVisibleText(city);
	}

	public WebElement getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public WebElement getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		driver.findElement(By.cssSelector("input[value="+hobbies+"]")).click();
	}
	public WebElement getRstButton() {
		return rstButton;
	}

	public void setRstButton() {
		this.rstButton.click();
	}
}
